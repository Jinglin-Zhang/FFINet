import torch
import torch.nn.functional as F

# 假设 backbone_feature 是通过 backbone 网络得到的特征图
# 可以是原始图像 (F_orig) 或增强图像 (F_aug)

def compute_attention_map(backbone_feature):
    # 计算全局平均池化特征
    gap_feature = torch.mean(backbone_feature, dim=1, keepdim=True)
    # 使用 Sigmoid 生成注意力图
    attention_map = torch.sigmoid(gap_feature)
    return attention_map


def dice_loss(attention1, attention2, smooth=1.0):
    # 将注意力图进行像素级二值化处理
    # print(torch.sum(attention1), torch.sum(attention2))

    attention1_bin = (attention1 > 0.5).float()
    attention2_bin = (attention2 > 0.5).float()

    intersection = (attention1_bin * attention2_bin).sum(dim=(1, 2, 3))
    union = attention1_bin.sum(dim=(1, 2, 3)) + attention2_bin.sum(dim=(1, 2, 3))

    dice = (2. * intersection + smooth) / (union + smooth)
    return 1 - dice.mean()  # 损失值

def bce_loss(attention1, attention2):
    # BCE Loss 直接作用于原始注意力图，而非二值化的结果
    return F.binary_cross_entropy(attention1, attention2)
