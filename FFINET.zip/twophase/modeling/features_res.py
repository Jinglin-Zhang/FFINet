import torch
import torch.nn as nn
import torch.nn.functional as F

class GradReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambda_):
        ctx.lambda_ = lambda_
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.lambda_ * grad_output, None

def grad_reverse(x, lambda_=1.0):
    return GradReverse.apply(x, lambda_)


class SelfAttention(nn.Module):
    def __init__(self, in_dim):
        super(SelfAttention, self).__init__()
        self.chanel_in = in_dim

        self.query_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        batchsize, C, width, height = x.size()
        proj_query = self.query_conv(x).view(batchsize, -1, width * height).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(batchsize, -1, width * height)
        energy = torch.bmm(proj_query, proj_key)
        attention = F.softmax(energy, dim=-1)
        proj_value = self.value_conv(x).view(batchsize, -1, width * height)

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = out.view(batchsize, C, width, height)

        out = self.gamma * out + x
        return out

class FCDiscriminator_img(nn.Module):
    def __init__(self, num_classes, ndf1=256, ndf2=128, ndf3=64):
        super(FCDiscriminator_img, self).__init__()

        self.conv1 = nn.Conv2d(num_classes, ndf1, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(ndf1)
        self.prelu1 = nn.PReLU()

        self.conv2 = nn.Conv2d(ndf1, ndf2, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(ndf2)
        self.prelu2 = nn.PReLU()

        self.conv3 = nn.Conv2d(ndf2, ndf3, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(ndf3)
        self.prelu3 = nn.PReLU()

        self.conv4 = nn.Conv2d(ndf3, ndf3, kernel_size=3, padding=1)
        self.bn4 = nn.BatchNorm2d(ndf3)
        self.prelu4 = nn.PReLU()

        self.classifier = nn.Conv2d(ndf3, 1, kernel_size=3, padding=1)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.prelu1(x)

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.prelu2(x)

        x = self.conv3(x)
        x = self.bn3(x)
        x = self.prelu3(x)

        x = self.conv4(x)
        x = self.bn4(x)
        x = self.prelu4(x)

        x = self.classifier(x)
        return x

#################################


# 假设FCDiscriminator_img和SelfAttention类已定义
class FeatureProcessor(nn.Module):
    def __init__(self, num_classes, ndf1=256, ndf2=128, ndf3=64):
        super(FeatureProcessor, self).__init__()
        self.discriminator = FCDiscriminator_img(num_classes, ndf1, ndf2, ndf3)
        self.self_attention = SelfAttention(in_dim=2048)  # 假设输入特征维度是2048

    def forward(self, f_r):
        # 梯度反转
        f_r1 = grad_reverse(f_r)
        # 通过鉴别器
        f_r1 = self.discriminator(f_r1)

        # 自注意力
        f_r2 = self.self_attention(f_r)

        # 融合
        fused = f_r1 + f_r2

        # 再次自注意力
        f_s = self.self_attention(fused)

        # 残差连接
        output = f_s + f_r
        return output


# # 使用示例
# model = FeatureProcessor(num_classes=2048)  # 假设num_classes是2048
# f_r = torch.randn(6, 2048, 42, 84)  # 示例输入
# output = model(f_r)
# print(output.shape)
