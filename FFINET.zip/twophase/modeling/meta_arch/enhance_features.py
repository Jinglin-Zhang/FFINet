import torch


def enhance_features(self, features, positive_samples):
    """
    Apply mask to features to enhance strong features based on positive sample boxes.

    Args:
        features (dict[str, torch.Tensor]): feature maps from the backbone
        positive_samples (list[torch.Tensor]): list of positive sample boxes for each image

    Returns:
        dict[str, torch.Tensor]: enhanced features
    """
    enhanced_features = {}

    for name, feature in features.items():
        # Create an empty mask with the same spatial dimensions as the feature map
        mask = torch.zeros_like(feature)

        for i, pos_boxes in enumerate(positive_samples):
            for box in pos_boxes:
                # Get the coordinates of the box
                x1, y1, x2, y2 = box.int()

                # Set the corresponding area in the mask to 1
                mask[i, :, y1:y2, x1:x2] = 1

        # Apply the mask to the feature map to retain only the regions corresponding to positive samples
        enhanced_feature = feature * mask

        # Store the enhanced feature map
        enhanced_features[name] = enhanced_feature

    return enhanced_features
