from os.path import join
from numpy.core.fromnumeric import size
import torch
import torch.nn.functional as F
from tqdm import tqdm

from detectron2.structures import Instances, Boxes

def substructure_matching_L2(targets_src, boxes_t, label_num):

    # print("targets_src:", targets_src)
    # print("boxes_t:", boxes_t)
    # print("label_num:", label_num)
    # 获取目标标签数量
    n = len(targets_src.gt_classes)
    # print("n (number of targets):", n)
    if n != label_num:
        print("Number of targets does not match label_num")
        return torch.tensor(0, device='cuda', dtype=float)

    label_s = targets_src.gt_classes
    box_s = targets_src.gt_boxes.tensor
    label_t = boxes_t.gt_classes
    box_t = boxes_t.gt_boxes.tensor

    # print("label_s:", label_s)
    # print("box_s:", box_s)
    # print("label_t:", label_t)
    # print("box_t:",box_t)

    if label_t.numel() == 0:
        print("label_t is empty")
        return torch.tensor(0, device='cuda', dtype=float)

    # print("Original label_t:", label_t)
    # print("Original box_t:", box_t)

    sorted_indices = torch.argsort(label_s)
    label_s = label_s[sorted_indices]
    box_s = box_s[sorted_indices]

    # arr = []
    # for i in range(label_t.min().item(), label_t.max().item() + 1):
    #     l = torch.where(label_t == i)
    #     if l[0].shape[0] != 0:
    #         arr.append(l[0][0].item())
    #
    # label_t = label_t[arr]
    # box_t = box_t[arr]
    #
    # print("Filtered label_t:", label_t)
    # print("Filtered box_t:", box_t)
    # print("arr (filtered indices):", arr)

    if label_t.shape[0] != label_num:
        print("Filtered label_t shape does not match label_num")
        return torch.tensor(0, device='cuda', dtype=float)

    midpoint_s = []
    midpoint_t = []
    for i in range(n):
        midpoint_s.append([(box_s[i][0] + box_s[i][2]) / 2, (box_s[i][1] + box_s[i][3]) / 2])
        midpoint_t.append([(box_t[i][0] + box_t[i][2]) / 2, (box_t[i][1] + box_t[i][3]) / 2])

    coordinates_s = torch.tensor(midpoint_s, device='cuda')
    coordinates_t = torch.tensor(midpoint_t, device='cuda')

    adjacency_matrix_s = torch.zeros(label_num, label_num, device='cuda')
    adjacency_matrix_t = torch.zeros(label_num, label_num, device='cuda')

    # print("adjacency_matrix_s:",adjacency_matrix_s)
    # print("adjacency_matrix_t:",adjacency_matrix_t)

    for i in range(label_num):
        for j in range(label_num):
            if i != j:
                angle_s = calculate_angle(coordinates_s[i], coordinates_s[j])
                angle_t = calculate_angle(coordinates_t[i], coordinates_t[j])
                adjacency_matrix_s[i][j] = angle_s
                adjacency_matrix_t[i][j] = angle_t

    diff = adjacency_matrix_s - adjacency_matrix_t
    squared_diff = diff.pow(2)
    loss = torch.sqrt(squared_diff.sum(dim=1))


    # print("loss:",loss)
    log_loss = torch.log1p(loss)  # Use log1p to avoid log(0)

    n_log_loss = log_loss / label_num

    # print(n_log_loss)
    # # Normalize the log-transformed losses so that their sum is 1
    # sum_halved_log_loss = sum(halved_log_loss)
    # normalized_halved_log_loss = halved_log_loss / sum_halved_log_loss
    # print(normalized_halved_log_loss)
    # print(sum(normalized_halved_log_loss))
    # print(sum(normalized_loss))
    last_loss = sum(n_log_loss) / label_num
    return last_loss


# def substructure_matching_L2(targets_src, boxes_t, label_num):
#     if len(targets_src) != label_num:
#         return torch.tensor(0, device='cuda', dtype=float)
#
#     label_s = torch.cat(targets_src)
#     box_s = torch.cat(boxes_t)
#
#     label_t = torch.cat(targets_src)
#     box_t = torch.cat(boxes_t)
#
#     sorted_indices = torch.argsort(label_s)
#     label_s = label_s[sorted_indices]
#     box_s = box_s[sorted_indices]
#
#     arr = []
#     for i in range(label_t.min(), label_t.max() + 1):
#         l = torch.where(label_t == i)
#         if l is not None and l[0].shape[0] != 0:
#             arr.append(l[0][0].item())
#
#     label_t = label_t[arr]
#     box_t = box_t[arr]
#
#     if label_t.shape[0] != label_num:
#         return torch.tensor(0, device='cuda', dtype=float)
#
#     midpoint_s = []
#     midpoint_t = []
#     for i in range(label_num):
#         midpoint_s.append([(box_s[i][0] + box_s[i][2]) / 2, (box_s[i][1] + box_s[i][3]) / 2])
#         midpoint_t.append([(box_t[i][0] + box_t[i][2]) / 2, (box_t[i][1] + box_t[i][3]) / 2])
#
#     coordinates_s = torch.tensor(midpoint_s)
#     coordinates_t = torch.tensor(midpoint_t)
#
#     adjacency_matrix_s = torch.zeros(label_num, label_num).to(device='cuda')
#     adjacency_matrix_t = torch.zeros(label_num, label_num).to(device='cuda')
#
#     for i in range(label_num):
#         for j in range(label_num):
#             if i != j:
#                 angle_s = calculate_angle(coordinates_s[i], coordinates_s[j])
#                 angle_t = calculate_angle(coordinates_t[i], coordinates_t[j])
#                 adjacency_matrix_s[i][j] = angle_s
#                 adjacency_matrix_t[i][j] = angle_t
#
#     diff = adjacency_matrix_s - adjacency_matrix_t
#     squared_diff = diff.pow(2)
#     loss = torch.sqrt(squared_diff.sum(dim=1))
#
#     return sum(loss)


def calculate_angle(point1, point2):
    delta_x = point2[0] - point1[0]
    delta_y = point2[1] - point1[1]
    angle = torch.atan2(delta_y, delta_x)
    return angle


def extract_data_from_label_data(label_data):
    extracted_data = []

    for data in label_data:
        # print(data)
        image_height = data['height']
        image_width = data['width']
        image_tensor = data['image']

        image_size = (image_height, image_width)

        instances = Instances(image_size=image_size)
        # instances = Instances(image_height=image_height, image_width=image_width)

        # 确保 gt_boxes 是一个二维张量
        gt_boxes_tensor = data['instances'].gt_boxes.tensor
        if gt_boxes_tensor.dim() == 1:
            gt_boxes_tensor = gt_boxes_tensor.unsqueeze(0)

        instances.gt_boxes = Boxes(gt_boxes_tensor)
        instances.gt_classes = data['instances'].gt_classes

        extracted_data.append({
            'image_height': image_height,
            'image_width': image_width,
            'image_tensor': image_tensor,
            'instances': instances
        })

    return extracted_data

def extract_data_from_label_data_1(label_data):
    extracted_data = []

    for data in label_data:

        # print("data:", data)  # 输出整个 data 对象

        # print("Instances:",data.pred_boxes.tensor)
        # print("data['instances']:", dir(data['Instances']))
        # fields = data['Instances'].fields
        # print("ok---------------------------")


        # print(f"gt_boxes_tensor shape: {gt_boxes_tensor.shape}")



        image_height, image_width = data.image_size

        instances = Instances(image_size=(image_height, image_width))

        if isinstance(data.pred_boxes, Boxes):
            gt_boxes_tensor = data.pred_boxes.tensor
        else:
            gt_boxes_tensor = data.pred_boxes

        if gt_boxes_tensor.dim() == 1:
            gt_boxes_tensor = gt_boxes_tensor.unsqueeze(0)
        # Assign ground truth boxes to instances
        instances.gt_boxes = Boxes(gt_boxes_tensor)

        # Ensure pred_classes is accessed correctly
        instances.gt_classes = data.pred_classes

        extracted_data.append({
            'instances': instances
        })

    return extracted_data