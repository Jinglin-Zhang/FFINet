import torch
import torch.nn as nn
import torch.nn.functional as F
from mobile_sam import sam_model_registry, SamAutomaticMaskGenerator, SamPredictor
# from segment_anything import SamPredictor, sam_model_registry, SamAutomaticMaskGenerator
class ViTHuge(nn.Module):
    def __init__(self):
        super(ViTHuge, self).__init__()
        mobile_sam = sam_model_registry["vit_t"](checkpoint="/home/kemove/xmm/2pcnet/twophase/modeling/sam_enconde/MobileSAM-master/weights/mobile_sam.pt")
        self.features = mobile_sam.image_encoder

        for param in self.features.parameters():
            param.requires_grad = False

    def forward(self, x):
        x = F.interpolate(x, size=(1024, 1024), mode='bilinear', align_corners=True)
        with torch.no_grad():
            x = self.features(x)
        return x

class MLPFeatureAligner(nn.Module):
    def __init__(self, in_channels_sam, out_channels_res5):
        super(MLPFeatureAligner, self).__init__()
        self.fc1 = nn.Linear(in_channels_sam, 512)
        self.fc2 = nn.Linear(512, out_channels_res5)
        self.relu = nn.ReLU()

    def forward(self, features_sam, features_res5):
        batch_size, channels, height, width = features_sam.shape
        features_sam = features_sam.view(batch_size, channels, -1).permute(0, 2, 1)  # [batch_size, height*width, channels]
        features_sam = self.fc1(features_sam)
        features_sam = self.relu(features_sam)
        features_sam = self.fc2(features_sam)
        features_sam = features_sam.permute(0, 2, 1).view(batch_size, -1, height, width)
        aligned_features_sam = F.interpolate(features_sam, size=features_res5.shape[2:], mode='bilinear', align_corners=False)
        return aligned_features_sam

class SelfAttention(nn.Module):
    def __init__(self, dim):
        super(SelfAttention, self).__init__()
        self.query = nn.Conv2d(dim, dim, kernel_size=1)
        self.key = nn.Conv2d(dim, dim, kernel_size=1)
        self.value = nn.Conv2d(dim, dim, kernel_size=1)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        B, C, H, W = x.shape
        query = self.query(x).view(B, C, -1).permute(0, 2, 1)  # (B, N, C)
        key = self.key(x).view(B, C, -1)  # (B, C, N)
        value = self.value(x).view(B, C, -1).permute(0, 2, 1)  # (B, N, C)
        attention = torch.bmm(query, key)  # (B, N, N)
        attention = self.softmax(attention)
        out = torch.bmm(attention, value)  # (B, N, C)
        out = out.permute(0, 2, 1).view(B, C, H, W)
        return out

class CrossAttention(nn.Module):
    def __init__(self, dim):
        super(CrossAttention, self).__init__()
        self.query = nn.Conv2d(dim, dim, kernel_size=1)
        self.key = nn.Conv2d(dim, dim, kernel_size=1)
        self.value = nn.Conv2d(dim, dim, kernel_size=1)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x1, x2):
        B, C, H, W = x1.shape
        query = self.query(x1).view(B, C, -1).permute(0, 2, 1)  # (B, N, C)
        key = self.key(x2).view(B, C, -1)  # (B, C, N)
        value = self.value(x2).view(B, C, -1).permute(0, 2, 1)  # (B, N, C)
        attention = torch.bmm(query, key)  # (B, N, N)
        attention = self.softmax(attention)
        out = torch.bmm(attention, value)  # (B, N, C)
        out = out.permute(0, 2, 1).view(B, C, H, W)
        return out

class FeatureAggregator(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(FeatureAggregator, self).__init__()
        self.self_attention_sam = SelfAttention(in_channels)
        self.self_attention_res5 = SelfAttention(in_channels)
        self.cross_attention = CrossAttention(in_channels)
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, features_sam, features_res5):
        features_sam = self.self_attention_sam(features_sam)
        features_res5 = self.self_attention_res5(features_res5)
        features_cross = self.cross_attention(features_sam, features_res5)
        aggregated_features = features_sam + features_res5 + features_cross
        aggregated_features = self.conv(aggregated_features)
        if aggregated_features.shape[1] != features_res5.shape[1]:
            aggregated_features = F.interpolate(aggregated_features, size=features_res5.shape[2:], mode='bilinear', align_corners=False)
        return aggregated_features

class SAMResNetFeatureFusion(nn.Module):
    def __init__(self, in_channels_sam, out_channels_res5):
        super(SAMResNetFeatureFusion, self).__init__()
        self.vit_huge = ViTHuge()
        self.mlp_aligner = MLPFeatureAligner(in_channels_sam, out_channels_res5)
        self.aggregator = FeatureAggregator(out_channels_res5, out_channels_res5)

    def forward(self, image_tensor, features_res5):
        features_sam = self.vit_huge(image_tensor)
        aligned_features_sam = self.mlp_aligner(features_sam, features_res5)
        features_new = self.aggregator(aligned_features_sam, features_res5)
        return features_new

class extract_sam_features(nn.Module):
    def __init__(self, in_channels_sam, out_channels_res5):
        super(extract_sam_features, self).__init__()
        self.vit_huge = ViTHuge()
        self.mlp_aligner = MLPFeatureAligner(in_channels_sam, out_channels_res5)


    def forward(self, image_tensor, features_res5):
        features_sam = self.vit_huge(image_tensor)
        aligned_features_sam = self.mlp_aligner(features_sam, features_res5)

        return aligned_features_sam

