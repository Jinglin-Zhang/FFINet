import torch
import torchvision.transforms as T
import torch.nn.functional as F
import numpy as np
from numpy import random as R
import cv2
from torchvision.transforms.functional import gaussian_blur
from scipy.special import gamma


class NightAug:
    def __init__(self):
        self.gaussian = T.GaussianBlur(11, (0.1, 2.0))

    def mask_img(self, img, cln_img):
        while R.random() > 0.4:
            x1 = R.randint(img.shape[1])
            x2 = R.randint(img.shape[1])
            y1 = R.randint(img.shape[2])
            y2 = R.randint(img.shape[2])
            img[:, x1:x2, y1:y2] = cln_img[:, x1:x2, y1:y2]
        return img

    def gaussian_heatmap(self, x):
        """
        It produces single gaussian at a random point
        """
        sig = torch.randint(low=1, high=150, size=(1,)).cuda()[0]
        image_size = x.shape[1:]
        center = (torch.randint(image_size[0], (1,))[0].cuda(), torch.randint(image_size[1], (1,))[0].cuda())
        x_axis = torch.linspace(0, image_size[0] - 1, image_size[0]).cuda() - center[0]
        y_axis = torch.linspace(0, image_size[1] - 1, image_size[1]).cuda() - center[1]
        xx, yy = torch.meshgrid(x_axis, y_axis)
        kernel = torch.exp(-0.5 * (torch.square(xx) + torch.square(yy)) / torch.square(sig))
        new_img = (x * (1 - kernel) + 255 * kernel).type(torch.uint8)
        return new_img

    def rgb_to_ycbcr(self, rgb):
        """RGB to YCbCr conversion"""
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2YCrCb)

    def ycbcr_to_rgb(self, ycbcr):
        """YCbCr to RGB conversion"""
        return cv2.cvtColor(ycbcr, cv2.COLOR_YCrCb2RGB)

    def guided_filter(self, I, p, r, eps):
        """Apply guided filtering."""
        return cv2.ximgproc.guidedFilter(I, p, r, eps)

    def apply_retinex_with_guided_filter(self, image, radius, eps, s):
        """Enhance image using Retinex algorithm with guided filter."""
        small_image = cv2.resize(image, (0, 0), fx=1 / s, fy=1 / s, interpolation=cv2.INTER_LINEAR)
        refined_image = self.guided_filter(small_image, small_image, radius, eps)  # Use radius here
        return cv2.resize(refined_image, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)

    def fractional_derivative_mask(self, image, order=0.2, kernel_size=3):
        """Apply fractional derivative mask to an image."""
        center = kernel_size // 2
        coefficients = [((-1) ** n) * (gamma(order + 1) / (gamma(n + 1) * gamma(order - n + 1)))
                        for n in range(kernel_size)]
        kernel = np.zeros((kernel_size, kernel_size))
        kernel[center, :] = coefficients
        fd_image = cv2.filter2D(image, -1, kernel)
        return fd_image

    def process_image(self, image):
        """Process and enhance the image."""

        ycbcr_image = self.rgb_to_ycbcr(image)

        y_channel, Cr, Cb = cv2.split(ycbcr_image)

        # Apply Retinex with guided filter to Y channel
        enhanced_y = self.apply_retinex_with_guided_filter(y_channel, radius=8, eps=0.3, s=1)

        # Apply fractional derivative mask to enhance details
        final_y = self.fractional_derivative_mask(enhanced_y)

        # Combine enhanced Y channel with original Cb and Cr channels
        enhanced_ycbcr = cv2.merge((final_y, Cr, Cb))
        final_image = self.ycbcr_to_rgb(enhanced_ycbcr)

        return final_image

    def aug(self, x):
        for sample in x:
            img1 = sample['image'].cpu().numpy().transpose(1, 2, 0)  # Convert tensor to numpy for OpenCV
            img1 = (img1 * 255).astype(np.uint8)  # Assume image tensor is normalized (0-1), convert to 0-255

            # Apply image enhancement
            enhanced_img = self.process_image(img1)

            # Convert back to tensor format
            enhanced_img_glocal = torch.from_numpy(enhanced_img.transpose(2, 0, 1)).float() / 255.0
            enhanced_img_glocal = enhanced_img_glocal.to('cuda')

            img = sample['image'].cuda()

            alpha = 0.5 # 设置融合权重



            g_b_flag = True

            # # Guassian Blur
            # if R.random() > 0.5:
            #     img = self.gaussian(img)
            #     img = self.mask_img(img, img.detach().clone())
            #
            #
            # # Gamma
            # if R.random() > 0.5:
            #     cln_img = img.detach().clone()
            #     val = 1 / (R.random() * 0.8 + 0.2)
            #     img = T.functional.adjust_gamma(img, val)
            #     img = self.mask_img(img, cln_img)
            #     g_b_flag = False
            #
            #
            # prob = 0.5
            # while R.random() > prob:
            #     img = self.gaussian_heatmap(img)
            #     # prob += 0.1


            # Apply MSRCR
            # img = self.MSRCR(img)
            img2 = img
            bboxes = sample['instances'].gt_boxes.tensor
            num_selected_bboxes = round(len(bboxes) * 0.3) if len(bboxes) > 3 else 1
            selected_bbox_indices = np.random.choice(len(bboxes), num_selected_bboxes, replace=False)
            for bbox_idx in selected_bbox_indices:
                scales = [3,5,7]
                bbox = bboxes[bbox_idx]
                x1, y1, x2, y2 = bbox
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

                local_region = img2[:, y1:y2, x1:x2]  # 提取局部区域
                local_region = local_region.float() / 255.0
                local_log = torch.log1p(local_region)

                local_msrcr = torch.zeros_like(local_log)
                for scale in scales:
                    kernel_size = min(2 * scale + 1, y2 - y1, x2 - x1)  # 限制核大小不超过局部区域尺寸
                    if kernel_size % 2 == 0:  # 确保核大小为奇数
                        kernel_size += 1
                    if kernel_size > 1:  # 避免尺寸为1的核
                    # 应用高斯模糊
                        local_smooth = gaussian_blur(local_log, kernel_size=kernel_size, sigma=scale)
                        local_msrcr += local_log - local_smooth

                local_msrcr = torch.expm1(local_msrcr)
                local_msrcr = torch.clamp(local_msrcr * 255.0, 0, 255)
                img2[:, y1:y2, x1:x2] = local_msrcr.type(torch.uint8)  # 将处理后的区域替换回原图
                # print(bbox1)
                # img = self.local_msrcr(img, bbox)  # 对每个边界框内的区域应用MSRCR
            img = alpha * img2 + (1 - alpha) * enhanced_img_glocal

            sample['image'] = img.cpu()
        return x



