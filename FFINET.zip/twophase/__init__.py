from .config import add_teacher_config
